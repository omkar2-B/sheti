import siteData from './data.js';

class App {
    constructor() {
        this.cart = JSON.parse(localStorage.getItem('cart')) || [];
        this.currentCategory = 'all';
        this.searchTerm = '';
        
        this.init();
        this.registerServiceWorker();
    }

    init() {
        this.renderBusinessInfo();
        this.renderCategories();
        this.renderProducts();
        this.updateCartUI();
        this.setupEventListeners();
        this.checkOfferPopup();
    }

    renderBusinessInfo() {
        document.querySelectorAll('.biz-name').forEach(el => el.textContent = siteData.business.name);
        document.querySelectorAll('.biz-slogan').forEach(el => el.textContent = siteData.business.slogan);
        document.querySelectorAll('.biz-owner').forEach(el => el.textContent = siteData.business.owner);
    }

    renderCategories() {
        const container = document.getElementById('category-container');
        if (!container) return;
        
        container.innerHTML = siteData.categories.map(cat => `
            <div class="category-pill ${this.currentCategory === cat.id ? 'active' : ''}" 
                 data-id="${cat.id}">
                ${cat.name}
            </div>
        `).join('');
    }

    renderProducts() {
        const container = document.getElementById('product-grid');
        if (!container) return;

        let filtered = siteData.products;
        
        if (this.currentCategory !== 'all') {
            filtered = filtered.filter(p => p.category === this.currentCategory);
        }

        if (this.searchTerm) {
            const term = this.searchTerm.toLowerCase();
            filtered = filtered.filter(p => 
                p.name.toLowerCase().includes(term) || 
                (p.description && p.description.toLowerCase().includes(term))
            );
        }

        if (filtered.length === 0) {
            container.innerHTML = `
                <div style="grid-column: 1/-1; text-align: center; padding: 50px; color: #999;">
                    <i class="fas fa-search fa-3x" style="margin-bottom: 20px; opacity: 0.3;"></i>
                    <p>क्षमस्व, कोणतेही उत्पादन आढळले नाही.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = filtered.map(p => `
            <div class="product-card">
                <div class="product-image">
                    <img src="${p.image || 'https://via.placeholder.com/300x200?text=No+Image'}" alt="${p.name}" loading="lazy">
                    ${p.badge ? `<div class="product-badge">${p.badge}</div>` : ''}
                </div>
                <div class="product-details">
                    <h3 class="product-name">${p.name}</h3>
                    <p class="product-price">₹${p.price} <small>/ ${p.unit}</small></p>
                    <button class="add-to-cart" data-id="${p.id}">
                        <i class="fas fa-cart-plus"></i> ताटात भरा
                    </button>
                </div>
            </div>
        `).join('');
    }

    setupEventListeners() {
        // Category switching
        document.getElementById('category-container')?.addEventListener('click', (e) => {
            const pill = e.target.closest('.category-pill');
            if (pill) {
                this.currentCategory = pill.dataset.id;
                this.renderCategories();
                this.renderProducts();
                document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
            }
        });

        // Search
        document.getElementById('search-input')?.addEventListener('input', (e) => {
            this.searchTerm = e.target.value;
            this.renderProducts();
        });

        // Add to cart
        document.getElementById('product-grid')?.addEventListener('click', (e) => {
            const btn = e.target.closest('.add-to-cart');
            if (btn) {
                const id = parseInt(btn.dataset.id);
                this.addToCart(id);
            }
        });

        // Toggle cart
        const toggleCart = () => {
            document.getElementById('cart-drawer').classList.toggle('open');
            document.body.style.overflow = document.getElementById('cart-drawer').classList.contains('open') ? 'hidden' : '';
        };

        document.querySelectorAll('.toggle-cart').forEach(el => {
            el.addEventListener('click', toggleCart);
        });

        // Checkout button
        document.getElementById('checkout-btn')?.addEventListener('click', () => {
            this.checkout();
        });
    }

    addToCart(id) {
        const product = siteData.products.find(p => p.id === id);
        const existing = this.cart.find(item => item.id === id);

        if (existing) {
            existing.quantity += 1;
        } else {
            this.cart.push({ ...product, quantity: 1 });
        }

        this.saveCart();
        this.updateCartUI();
        this.showToast(`${product.name} ताटात भरले!`);
    }

    saveCart() {
        localStorage.setItem('cart', JSON.stringify(this.cart));
    }

    updateCartUI() {
        const container = document.getElementById('cart-items');
        const count = document.getElementById('cart-count');
        const totalEl = document.getElementById('cart-total-amount');

        const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);
        if (count) count.textContent = totalItems;

        if (!container) return;

        if (this.cart.length === 0) {
            container.innerHTML = `
                <div style="text-align:center; color:#999; margin-top:100px;">
                    <i class="fas fa-shopping-basket fa-4x" style="margin-bottom: 20px; opacity: 0.1;"></i>
                    <p>तुमचे ताट रिकामे आहे...</p>
                    <button class="btn-primary toggle-cart" style="margin-top:20px; padding: 10px 20px; font-size:0.9rem;">खरेदी सुरू करा</button>
                </div>
            `;
            if (totalEl) totalEl.textContent = '0';
            return;
        }

        let total = 0;
        container.innerHTML = this.cart.map(item => {
            const itemTotal = item.price * item.quantity;
            total += itemTotal;
            return `
                <div class="cart-item" style="display:flex; gap:15px; margin-bottom:20px; align-items:center; padding-bottom:15px; border-bottom:1px solid #eee;">
                    <img src="${item.image}" style="width:70px; height:70px; border-radius:12px; object-fit:cover;">
                    <div style="flex:1;">
                        <h4 style="font-size:0.95rem; margin-bottom:4px;">${item.name}</h4>
                        <p style="color:var(--primary); font-weight:700; font-size:1rem;">₹${item.price} <small style="font-weight:400; color:#666;">x ${item.quantity}</small></p>
                    </div>
                    <div style="display:flex; flex-direction:column; align-items:flex-end; gap:8px;">
                        <p style="font-weight:700; font-size:0.9rem;">₹${itemTotal}</p>
                        <button onclick="window.app.removeFromCart(${item.id})" style="border:none; background:#fff1f0; color:#ff4d4f; cursor:pointer; width:30px; height:30px; border-radius:50%; display:flex; align-items:center; justify-content:center;">
                            <i class="fas fa-trash-alt" style="font-size:0.8rem;"></i>
                        </button>
                    </div>
                </div>
            `;
        }).join('');

        if (totalEl) totalEl.textContent = total;
    }

    removeFromCart(id) {
        this.cart = this.cart.filter(item => item.id !== id);
        this.saveCart();
        this.updateCartUI();
    }

    checkout() {
        if (this.cart.length === 0) return alert("कृपया आधी काही खरेदी करा!");

        const total = this.cart.reduce((sum, i) => sum + (i.price * i.quantity), 0);
        const message = `*नवीन ऑर्डर (Gavathi Shetmal)*\n\n` + 
            this.cart.map(item => `- *${item.name}* (${item.quantity} ${item.unit}) : ₹${item.price * item.quantity}`).join('\n') +
            `\n\n*एकूण रक्कम:* ₹${total}` +
            `\n\n------------------\nकृपया डिलिव्हरीसाठी आपला पत्ता आणि नाव पाठवा.`;

        const url = `https://wa.me/91${siteData.business.whatsapp}?text=${encodeURIComponent(message)}`;
        window.open(url, '_blank');
        
        // Optionally clear cart or keep it
        // this.cart = [];
        // this.saveCart();
        // this.updateCartUI();
    }

    showToast(msg) {
        const container = document.getElementById('toast-container');
        if (!container) return;

        const toast = document.createElement('div');
        toast.style.cssText = `
            background: #1a1a1a;
            color: white;
            padding: 12px 25px;
            border-radius: 50px;
            margin-bottom: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideUp 0.3s ease-out;
        `;
        toast.innerHTML = `<i class="fas fa-check-circle" style="color: #52c41a;"></i> ${msg}`;
        container.appendChild(toast);
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(10px)';
            toast.style.transition = '0.3s';
            setTimeout(() => toast.remove(), 300);
        }, 2500);
    }

    checkOfferPopup() {
        const hasSeen = sessionStorage.getItem('offer_seen');
        if (!hasSeen && siteData.offerPopup && siteData.offerPopup.active === 'yes') {
            const modal = document.getElementById('offer-modal');
            const titleEl = document.getElementById('popup-title');
            const msgEl = document.getElementById('popup-msg');
            if (modal && msgEl) {
                if (titleEl) titleEl.textContent = siteData.offerPopup.title;
                msgEl.textContent = siteData.offerPopup.message;
                setTimeout(() => {
                    modal.style.display = 'flex';
                    sessionStorage.setItem('offer_seen', 'true');
                }, 2000);
            }
        }
    }

    registerServiceWorker() {
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('./service-worker.js')
                .catch(err => console.log('SW registration failed', err));
            
            window.addEventListener('beforeinstallprompt', (e) => {
                e.preventDefault();
                const deferredPrompt = e;
                const installBtn = document.getElementById('pwa-install-btn');
                if (installBtn) {
                    installBtn.style.display = 'flex';
                    installBtn.onclick = () => {
                        deferredPrompt.prompt();
                        deferredPrompt.userChoice.then(() => {
                            installBtn.style.display = 'none';
                        });
                    };
                }
            });
        }
    }
}

window.app = new App();
