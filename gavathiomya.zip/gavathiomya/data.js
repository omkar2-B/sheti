const siteData = {
    basicInfo: {
        businessName: "गावठी शेतमाल",
        slogan: "शिवारातून थेट ताटात ...",
        whatsappNo: "9011147755",
        themeColor: "#1b5e20",
        logo: "https://gavathishetmal.com/assets/img_670175.webp",
        englishName: "Gavathi Shetmal"
    },
    business: {
        name: "गावठी शेतमाल",
        englishName: "Gavathi Shetmal",
        slogan: "शिवारातून थेट ताटात ...",
        whatsapp: "9011147755",
        owner: "श्री. नितीन शिवाजी मळेकर",
        location: "Ajara, Kolhapur",
        deliveryAreas: ["Mumbai", "Navi Mumbai", "Ulwe", "Kokan Bhavan", "Panvel", "Uran"],
        social: {
            facebook: "#",
            instagram: "https://instagram.com/gavathishetmal",
            youtube: "https://www.youtube.com/@GavathiShetmal"
        }
    },
    offerPopup: {
        active: "yes",
        title: "SUMMER बंपर धमाका ..",
        message: "सर्व उत्पादनावर 5% खास सूट ..\nत्वरा करा !!"
    },
    categories: [
        { id: "all", name: "सर्व उत्पादने" },
        { id: "veg", name: "भाजीपाला (Veg)" },
        { id: "fruit", name: "ताजी फळे (Fruits)" },
        { id: "dry", name: "सुका मेवा (Dry Fruits)" }
    ],
    products: [
        {
            id: 1,
            name: "मेथी भाजी",
            category: "veg",
            price: 50,
            unit: "जुडी",
            image: "https://gavathishetmal.com/assets/img_895369.webp",
            description: "ताजी आणि नैसर्गिकरीत्या पिकवलेली मेथी भाजी.",
            badge: "ताजी"
        },
        {
            id: 2,
            name: "चकावत भाजी",
            category: "veg",
            price: 20,
            unit: "जुडी",
            image: "https://gavathishetmal.com/assets/img_368297.webp",
            description: "शुद्ध गावरान चव असलेली चकावत भाजी."
        },
        {
            id: 3,
            name: "हापूस आंबा",
            category: "fruit",
            price: 800,
            unit: "डझन",
            image: "https://gavathishetmal.com/assets/img_114202.webp",
            description: "अस्सल कोकणी हापूस आंबा, गोड आणि रसाळ.",
            badge: "Best Seller"
        },
        {
            id: 4,
            name: "काजूगर",
            category: "dry",
            price: 450,
            unit: "500g",
            image: "https://gavathishetmal.com/assets/img_458979.webp",
            description: "उत्तम प्रतीचे आणि ताजे काजूगर."
        },
        {
            id: 5,
            name: "फणस",
            category: "fruit",
            price: 300,
            unit: "नग",
            image: "https://gavathishetmal.com/assets/img_939729.webp",
            description: "निसर्गदत्त गोडी असलेला ताजा फणस."
        }
    ]
};

export default siteData;
